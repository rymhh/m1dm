// Small proxy so the API key stays secret on the server.
export default async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const allowed = (process.env.ALLOWED_ORIGIN || "").trim();
  if (allowed && (req.headers.get("origin") || "") !== allowed) return new Response("Forbidden", { status: 403 });
  let body;
  try { body = await req.json(); } catch { return new Response("Bad request", { status: 400 }); }
  const prompt = String(body.prompt || "").slice(0, 6000);
  if (!prompt) return new Response("Bad request", { status: 400 });
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({ model: process.env.MODEL || "claude-sonnet-5-5", max_tokens: 1200, messages: [{ role: "user", content: prompt }] })
  });
  if (!r.ok) return new Response("Upstream error", { status: 502 });
  const d = await r.json();
  const text = (d.content || []).map(b => (b.type === "text" ? b.text : "")).join("");
  return Response.json({ text });
};
export const config = { path: "/api/ai" };

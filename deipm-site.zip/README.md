# DEIPM Partner Network: deploy on Netlify (free)

1. Create a free GitHub account, a new repository, and upload this folder's contents (public/, netlify/, netlify.toml).
2. Create a free Netlify account > "Add new site" > "Import from Git" > pick the repository. Leave the build settings as they are.
3. In Netlify: Site configuration > Environment variables, add:
   - ANTHROPIC_API_KEY = your key from console.anthropic.com
   - ALLOWED_ORIGIN = your final site address, e.g. https://your-site.netlify.app (no trailing slash)
4. Redeploy. Your site is live. Custom domain: Site configuration > Domain management.
5. In console.anthropic.com set a monthly spending limit, because anyone using the site spends your credit.

Without steps 3-4 the site still works, but the two AI buttons (local-organisation suggestions, email writing) will not.
